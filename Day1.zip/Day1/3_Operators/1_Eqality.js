var a = 45;
var b = "45";

var result = a == b;
console.log(result);

var result = a === b;
console.log(result);