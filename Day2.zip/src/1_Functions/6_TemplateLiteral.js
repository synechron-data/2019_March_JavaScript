var name = "Manish";
var message = "How are you?";

// // ES5
// var fMsg = "Hello " + name + ", " + message;
// console.log(fMsg);

// ES2015
var fMsg = `Hello 


${name}, 


        ${message}`;
console.log(fMsg);