'use strict'
// // a = 20;
// // console.log(a);

// var a;

// function Check() {
//     // var a = 20;
//     a = 20;
//     console.log("Inside Fn, a is:", a);
// }

// Check();
// console.log("Outside Fn, a is:", a);

// var a = 10;
// // var a = "ABC";
// a = "ABC";

// console.log(a);

var i = "Manish";
console.log("Before, i is:", i);

for (var i = 0; i < 5; i++) {
    console.log("Inside, i is:", i);
}

console.log("After, i is:", i);
