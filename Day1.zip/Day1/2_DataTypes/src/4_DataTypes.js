'use strict'

// var language;
// console.log("Language is: " + language);
// console.log("Type of Language is: " + typeof language);

// language = null;
// console.log("Language is: " + language);
// console.log("Type of Language is: " + typeof language);
// console.log("Type of Language is: " + typeof null);

// // language = 10;
// language = 10.5;
// console.log("Language is: " + language);
// console.log("Type of Language is: " + typeof language);

// // language = "JavaScript";
// language = 'JavaScript';
// console.log("Language is: " + language);
// console.log("Type of Language is: " + typeof language);

// language = true;
// console.log("Language is: " + language);
// console.log("Type of Language is: " + typeof language);

// var s = Symbol("Hello");
// console.log("s is: ", s);
// console.log("Type of s is: " + typeof s);

// // var c1 = { id: 1 };
// // var c2 = { id: 1 };

// // var color1 = 1;
// // var color2 = 1;
// // var color1 = Symbol(1);
// // var color2 = Symbol(1);

// // console.log(color1 == color2);
// // console.log(color1 === color2);

// a = 10;
// console.log(a);
// var a;

console.log(a);
var a = 10;