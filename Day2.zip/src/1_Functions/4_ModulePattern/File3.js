var dev1;

(function(ns){
    function Hello() {
        console.log("Hello from File 3");
    }

    ns.Hello = Hello;
})(dev1 = dev1 || {});