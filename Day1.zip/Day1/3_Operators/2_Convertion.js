// var age = window.prompt("What is your age?");
// document.write("Age is: " + age + "<br/>");

// var a1 = age + 10;
// document.write("New Age is: " + a1 + "<br/>");

// var a2 = parseInt(age) + 10;
// document.write("New Age is: " + a2 + "<br/>");

// var a3 = parseFloat(age) + 10;
// document.write("New Age is: " + a3 + "<br/>");

// var a4 = Number(age) + 10;
// document.write("New Age is: " + a4 + "<br/>");

// console.log(true && "ABC");
// console.log(false && "ABC");

// console.log(true && "ABC" || "XYZ");

console.log(Boolean(1));
console.log(Boolean(0));
console.log(Boolean(-1));
console.log(Boolean("ABC"));
console.log(Boolean(""));
console.log(Boolean(null));
console.log(Boolean(undefined));


// var obj = null;

// if (!obj) {
//     console.log("Is Null");
// }
// else {
//     console.log("Is not Null");
// }
