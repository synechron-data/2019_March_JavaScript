// const env = "dev";

// if (true) {
//     // env = "prod";
//     const env = "prod";
// }

// console.log(env);

const obj = { id: 1, name: "Manish" };

console.log(obj);
obj.id = 100;
// obj = {};

console.log(obj);
